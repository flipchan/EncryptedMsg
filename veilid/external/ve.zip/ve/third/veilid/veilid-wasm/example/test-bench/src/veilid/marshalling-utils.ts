export const textDecoder = new TextDecoder();
export const textEncoder = new TextEncoder();
