import { DhtStressTest } from './components/DhtStressTest';

function App() {
    return (
        <>
            <h1>DHT Stress Test</h1>
            <DhtStressTest />
        </>
    )
}

export default App
