# Veilid WASM Example - Test Bench

This is an example application used as a test bench for veilid-wasm.

* `npm install` to install dependencies.
* `npm run build:wasm` to build veilid-wasm so it can be used by the test bench.
* `npm run dev` to start the development server.