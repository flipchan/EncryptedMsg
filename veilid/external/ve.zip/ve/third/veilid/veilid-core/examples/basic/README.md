# Basic Example

Demonstration of simple Veilid application that just starts a node

## Running this example

Run this:

```
# cargo run --example basic-example
```
