#!/bin/bash
set -e
dart run build_runner build --delete-conflicting-outputs
