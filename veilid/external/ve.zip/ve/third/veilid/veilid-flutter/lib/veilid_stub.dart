import 'dart:typed_data';

import 'veilid.dart';

Veilid getVeilid() => throw UnsupportedError('Cannot create Veilid object');
Uint8List convertUint8ListFromJson(dynamic json) =>
    throw UnsupportedError('Cannot convertUint8ListFromJson');
dynamic convertUint8ListToJson(Uint8List data) =>
    throw UnsupportedError('Cannot convertUint8ListToJson');
