#!/bin/bash
flutter test -r expanded $@
