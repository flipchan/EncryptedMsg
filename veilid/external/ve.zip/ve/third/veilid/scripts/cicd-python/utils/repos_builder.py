import subprocess

def build_deb_repo():
    print("Creating and signing .deb package repository.")

def build_rpm_repo():
    print("Creating and signing .rpm package repository.")

