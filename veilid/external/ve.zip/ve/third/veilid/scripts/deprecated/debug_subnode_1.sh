#!/bin/bash
exec ./run_local_test.py 2 -w 1 --log_trace --config-file ./local-test.yml
