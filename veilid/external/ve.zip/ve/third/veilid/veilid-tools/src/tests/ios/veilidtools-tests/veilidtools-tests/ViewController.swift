//
//  ViewController.swift
//  veilidtools-tests
//
//  Created by JSmith on 6/27/21.
//

import UIKit
import Darwin

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        run_veilid_tools_tests()
        exit(0)
    }


}

