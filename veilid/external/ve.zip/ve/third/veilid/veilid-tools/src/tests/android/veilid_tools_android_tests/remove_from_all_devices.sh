#!/bin/bash
./adb+.sh uninstall com.veilid.veilid_tools_android_tests

