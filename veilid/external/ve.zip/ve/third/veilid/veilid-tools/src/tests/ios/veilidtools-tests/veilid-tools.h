//
//  veilid-tools.h
//  veilid-tools-tests
//
//  Created by JSmith on 7/6/21.
//

#ifndef veilid_tools_h
#define veilid_tools_h

void run_veilid_tools_tests(void);

#endif /* veilid-tools_h */
