#!/bin/bash
./gradlew installDebug
